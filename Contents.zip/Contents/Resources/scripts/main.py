from tkinter import *
import tkinter.ttk
from definitions import *
from Windows import *
import atexit
import pyglet
import shutil

window.title('MultiMine')
window.geometry("700x750+10+20")
window["background"] = Colors["Light"]["Cayan"]

for serve in os.listdir(MULTIMINE_PATH):
    if serve.endswith(".server"):
        if not os.path.exists(MULTIMINE_PATH+serve+"/server-icon.png"):
            shutil.copy("../Icon.png", MULTIMINE_PATH+serve+"/server-icon.png")


atexit.register(lambda: stop_and(True))

top = window.winfo_toplevel()
window.menuBar = Menu(top)
top['menu'] = window.menuBar

menu_run = Menu(window.menuBar)
window.menuBar.add_cascade(label="Run", menu=menu_run)
menu_run.add_command(label="start", command=run)
menu_run.add_command(label="stop", command=lambda: stop_and(False))

frame_tall = Frame(window, background=Colors["Cayan"], width=100, height=700)
frame_tall.place(x=0, y=0)

buttonsta = tkinter.ttk.Button(frame_tall, text="run", command=lambda: setuprun())
buttonsta.place(x=5, y=10)

buttonser = tkinter.ttk.Button(frame_tall, text="Servers", command=lambda: versions())
buttonser.place(x=5, y=50)

pyglet.font.add_file("../minecraft_font.ttf")

labels = tkinter.ttk.Style()
labels.theme_use('alt')
labels.configure('TLabel', font=
('Minecraft', 10),
foreground='Black',
background = Colors["Light"]["Cayan"])

inputs = tkinter.ttk.Style()
inputs.theme_use('alt')
inputs.configure('TEntry',
    font = ('Minecraft'),
    foreground="Black",
    borderwidth=0,
    relief=GROOVE,
    _cursor=5
)

buttons = tkinter.ttk.Style()
buttons.theme_use('alt')
buttons.configure('TButton', 
    background = Colors["Dark"]["Blue"], 
    foreground = Colors["Light"]["Blue"], 
    width = 10, 
    borderwidth=1, 
    focusthickness=3, 
    focuscolor='none',
    relief = GROOVE,
    overrelief = RAISED,
    disabledforeground = Colors["Light"]["Cayan"],
    font=('Minecraft', 10),)
buttons.map('TButton',
    background=[('active', '!disabled', Colors["Blue"]),
                ('disabled', Colors["Cayan"])],
    foreground=[('disabled', Colors["Light"]["Cayan"])])

rbuttons = tkinter.ttk.Style()
rbuttons.theme_use('alt')
rbuttons.configure('TRadiobutton', 
    background = Colors["Dark"]["Blue"], 
    foreground = Colors["Light"]["Blue"], 
    width = 8, 
    borderwidth=1, 
    focusthickness=3, 
    focuscolor='none',
    relief = GROOVE,
    overrelief = RAISED,
    )
rbuttons.map('TRadiobutton',
    background=[('active', "!selected", Colors["Blue"]),
        ('selected',Colors["Dark"]["Lucy"])],
    foreground=[('selected',Colors["Light"]["Lucy"])]
    )

roots = tkinter.ttk.Style()
roots.theme_use('alt')
roots.configure('.', 
    background = Colors["Dark"]["Blue"], 
    foreground = Colors["Light"]["Blue"], 
    font=('Minecraft', 10))

window.mainloop()
