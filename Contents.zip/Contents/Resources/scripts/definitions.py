from tkinter import scrolledtext, messagebox, filedialog
from Windows import *
import subprocess
import webbrowser
from tkinter import *
import tkinter.ttk
import threading
import time
import os
import shutil
import signal
from urllib.request import urlopen, urlretrieve
import json
from PIL import Image,ImageTk

Popen = []
players = []
options = open(MULTIMINE_PATH+'options.json', "r")
default_options = {"start": False, "stop": False, "console": False, "commandline": False, "java": False, "edition": "X"}
things = json.load(options)
global photos
photos = []
options.close()


def select_file(*types):
    file = filedialog.askopenfilename(initialdir="~/Downloads/", title="Select a File",
                                      filetypes=(*types, ("all folders", "*")))
    return file


def run_command(command):
    print("running " + command)
    things["java"].stdin.write(bytes(command + "\n", encoding="utf-8"))
    things["java"].stdin.flush()
    if command.lower() == "stop":
        things["stop"].configure(state=DISABLED)
        things["start"].configure(state=NORMAL)


def minecraft_thread():
    java = subprocess.Popen([
        MULTIMINE_PATH+"../frameworks/Java.framework/bin/Java",
        "-jar",
        MULTIMINE_PATH + things["edition"] + "server.jar",
        '--nogui'
    ],
        cwd=MULTIMINE_PATH + things["edition"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    things["java"] = java


def follow():
    console = things["console"]
    console.delete('1.0', END)
    file = open(MULTIMINE_PATH + things["edition"] + "logs/latest.log", "r")
    def _follow():
        endline = ""
        while True:
            try:
                line = file.readline()
                if not line: 
                    time.sleep(1)
                    continue
                print(endline)
                if endline == line:
                    time.sleep(1)
                if endline:
                    endline = line
                    yield endline
                time.sleep(0.1)
            except Exception as e: print(e)
    for line in _follow():
        try:
            things["console"].insert(END, line)
        except Exception as e: print(e)
        if line.endswith(" joined the game\n"):
            player = line.split(" ")[2]
            players.append(player)
            print(player + " is here! yay")
        elif line.endswith(" left the game\n"):
            player = line.split(" ")[2]
            print(player + " died. he is selfish and has abandoned us.")
            del player[player]
        elif "<" in line:
            player = line.split("<")[1].split(">")[0]
            content = line.split(">")[0]


def reset_window(w=windowp):
    for c in w.winfo_children():
        c.destroy()


def entrytexttofile(entry, number):
    number += 1
    text = entry.get()
    properties_file = MULTIMINE_PATH + things["edition"] + "server.properties"
    properties_read = open(properties_file, "r")
    lines = properties_read.readlines()
    properties_read.seek(number, 0)
    if text.endswith("\n"):
        lines[number] = lines[number].split("=")[0] + "=" + text
    else:
        lines[number] = lines[number].split("=")[0] + "=" + text + "\n"
    changed_file = open(properties_file, "w")
    changed_file.writelines(lines)
    changed_file.close()
    windowp.focus_set()


def toggle_button(button, number):
    number += 1
    buttontype = button["text"]
    properties_file = MULTIMINE_PATH + things["edition"] + "server.properties"
    properties_read = open(properties_file, "r")
    lines = properties_read.readlines()
    properties_read.seek(number, 0)
    if buttontype == "true":
        lines[number] = lines[number].split("=")[0] + "=false\n"
        button.config(text="false")
    if buttontype == "false":
        lines[number] = lines[number].split("=")[0] + "=true\n"
        button.config(text="true")
    properties_read.close()
    changed_file = open(properties_file, "w")
    changed_file.writelines(lines)
    changed_file.close()


def line_to_widgets(line, a, number):
    if not line.startswith("#"):
        key = line.split("=")[0]
        try:
            if line.split("=")[1] != "\n":
                value = line.split("=")[1]
            else:
                value = ""
        except IndexError:
            value = ""
        textbox = tkinter.ttk.Label(windowp, text=key, font=("Helvetica", 16))
        if value.startswith("true") or value.startswith("false"):
            if value.startswith("true"):
                truewidget = tkinter.ttk.Button(windowp, text="true", width=5)
                truewidget.config(command=lambda: toggle_button(truewidget, number))
                truewidget.grid(row=number, column=1)
            elif value.startswith("false"):
                falsewidget = tkinter.ttk.Button(windowp, text="false", width=5)
                falsewidget.config(command=lambda: toggle_button(falsewidget, number))
                falsewidget.grid(row=number, column=1)
        else:
            entry_widget = tkinter.ttk.Entry(windowp, font=('Minecraft'))
            entry_widget.insert(0, value)
            entry_widget.bind("<Return>", lambda b: entrytexttofile(entry_widget, number))
            entry_widget.grid(row=number, column=1)
        textbox.grid(row=number, column=0)


def run_lines(lines):
    line_to_widgets(lines[2], 60, 1)
    line_to_widgets(lines[3], 90, 2)
    line_to_widgets(lines[4], 120, 3)
    line_to_widgets(lines[5], 150, 4)
    line_to_widgets(lines[6], 180, 5)
    line_to_widgets(lines[7], 210, 6)
    line_to_widgets(lines[8], 240, 7)
    line_to_widgets(lines[9], 270, 8)
    line_to_widgets(lines[10], 300, 9)
    line_to_widgets(lines[11], 330, 10)
    line_to_widgets(lines[12], 360, 11)
    line_to_widgets(lines[13], 390, 12)
    line_to_widgets(lines[14], 420, 13)
    line_to_widgets(lines[15], 450, 14)
    line_to_widgets(lines[16], 480, 15)
    line_to_widgets(lines[17], 510, 16)
    line_to_widgets(lines[18], 540, 17)
    line_to_widgets(lines[19], 570, 18)
    line_to_widgets(lines[20], 600, 19)
    line_to_widgets(lines[21], 630, 20)
    line_to_widgets(lines[22], 660, 21)
    line_to_widgets(lines[23], 690, 22)
    line_to_widgets(lines[24], 720, 23)
    line_to_widgets(lines[25], 750, 24)
    line_to_widgets(lines[26], 780, 25)
    line_to_widgets(lines[27], 810, 26)
    line_to_widgets(lines[28], 840, 27)
    line_to_widgets(lines[29], 870, 28)
    line_to_widgets(lines[30], 900, 29)
    line_to_widgets(lines[31], 930, 30)
    line_to_widgets(lines[32], 960, 31)
    line_to_widgets(lines[33], 990, 32)
    line_to_widgets(lines[34], 1020, 33)
    line_to_widgets(lines[35], 1050, 34)
    line_to_widgets(lines[36], 1080, 35)
    line_to_widgets(lines[37], 1110, 36)
    line_to_widgets(lines[38], 1140, 37)
    line_to_widgets(lines[39], 1170, 38)
    line_to_widgets(lines[40], 1200, 39)
    line_to_widgets(lines[41], 1230, 40)
    line_to_widgets(lines[42], 1260, 41)
    line_to_widgets(lines[43], 1290, 42)
    line_to_widgets(lines[44], 1320, 43)
    line_to_widgets(lines[45], 1350, 44)
    line_to_widgets(lines[46], 1380, 45)
    line_to_widgets(lines[47], 1410, 46)
    line_to_widgets(lines[48], 1440, 47)


def properties(server):
    reset_window()
    properties_file = MULTIMINE_PATH + server + "/server.properties"
    properties_read = open(properties_file)
    lines = properties_read.readlines()
    topline = tkinter.ttk.Label(windowp, text="SERVER PROPERTIES")
    topline.grid(row=0, column=0)
    run_lines(lines)
    bottomline = tkinter.ttk.Label(windowp, text="Done!")
    bottomline.place(x=100, y=1530)
    properties_read.close()


def setuprun():
    reset_window()
    console = scrolledtext.ScrolledText(windowp, 
                                        width=62, 
                                        height=34, 
                                        background=Colors["Light"]["Blue"],
                                        foreground=Colors["Dark"]["Blue"],
                                        highlightcolor=Colors["Blue"],
                                        borderwidth=0,
                                        selectborderwidth=0,
                                        )
    console.place(x=40, y=150)
    start = tkinter.ttk.Button(windowp, text="Start", command=lambda: run())
    start.place(x=100, y=100)
    stop = tkinter.ttk.Button(windowp, text="Stop", command=lambda: stop_and(False))
    stop.place(x=300, y=100)
    commandline = tkinter.ttk.Entry(windowp, width=45, font=('Minecraft'))
    commandline.place(x=40, y=600)
    if things["java"] is False:
        stop.configure(state=DISABLED)
        start.configure(state=NORMAL)
    if things["java"] is not False:
        stop.configure(state=NORMAL)
        start.configure(state=DISABLED)
    things["stop"] = stop
    things["start"] = start
    things["console"] = console
    things["commandline"] = commandline

    def changefocus(a):
        try:
            commandline.focus_set()
        except:
            pass

    console.bind("<Enter>", lambda a: changefocus(None))
    try:
        latestlog = open(MULTIMINE_PATH + things["edition"] + "logs/latest.log", "r")
        console.insert(END, "".join(latestlog.readlines()))
        latestlog.close()
    except: pass
    console.bind("<FocusIn>", changefocus)
    label = tkinter.ttk.Label(windowp, text="Run Server")
    label.place(x=230, y=50)
    commandline.bind("<Return>", lambda a: run_command(things["commandline"].get()))
    
def run():
    if not things["java"]:
        pass

    def change_eula(eula, lines):
        path = eula.name
        eula.close()
        agreement = messagebox.askyesno("EULA", "To continue you have to agree to Minecraft's EULA\n"
                                              "found at: https://account.mojang.com/documents/minecraft_eula", icon='info')
        if agreement:
            lines[2] = "eula=true\n"
            eulagain = open(path, "w")
            eulagain.writelines(lines)
            eulagain.close()
    
    if not os.path.exists(MULTIMINE_PATH + things["edition"] + "eula.txt"):
        shutil.copy(MULTIMINE_PATH+"../Contents/Resources/eula_example.txt", MULTIMINE_PATH + things["edition"] + "eula.txt")
    eula = open(MULTIMINE_PATH + things["edition"] + "eula.txt", "r")
    lines = eula.readlines()
    if lines[2] == "eula=false\n":
        change_eula(eula, lines)
    else:
            eula.close()

    things["start"].configure(state=DISABLED)
    things["stop"].configure(state=NORMAL)
    thread = threading.Thread(target=minecraft_thread)
    thread.start()
    time.sleep(2)
    thread2 = threading.Thread(target=follow)
    thread2.start()
    signal.signal(15, lambda: stop_and(True))


def stop_and(exit_: bool):
    if things["java"]:
        run_command("stop")
        things["java"] = False
        if exit_:
            exit()


def versions():
    reset_window()
    title = tkinter.ttk.Label(windowp, text="Current Servers")
    title.place(x=230, y=50)
    add = tkinter.ttk.Button(windowp, text="add", command=lambda: addserver())
    add.place(x=50, y=50)

    num = 1
    servers = {}
    servar = StringVar()
    for server in os.listdir(MULTIMINE_PATH):
        if server.endswith(".server"):
            servers[str(num)] = server
            num += 1

    def setworld(opt):
        things["edition"] = opt
        options = open(MULTIMINE_PATH+'/options.json', "w")
        default_options["edition"] = opt
        json.dump(default_options, options)
        options.close()

    def add_server(numb, server, y):
        label = tkinter.ttk.Radiobutton(windowp, text=server.split(".server")[0], variable=servar, value=server + "/",
                            command=lambda: setworld(servar.get()))
        label.place(x=20, y=y)
        delete = tkinter.ttk.Button(windowp, text="Delete", command=lambda: delete_server(servers[numb]))
        delete.place(x=130, y=y)
        add = tkinter.ttk.Button(windowp, text="Worlds", command=lambda: worlds(servers[numb]))
        add.place(x=230, y=y)
        propert = tkinter.ttk.Button(windowp, text="Properties", command=lambda: properties(servers[numb]))
        propert.place(x=330, y=y)
        photos.append(ImageTk.PhotoImage(Image.open(MULTIMINE_PATH+servers[numb]+"/server-icon.png").resize((20,20), Image.ANTIALIAS)))
        icon = tkinter.ttk.Button(windowp, image=photos[len(photos)-1], command=lambda: change_icon(servers[numb]))
        icon.place(x=430, y=y-3)
        if server + "/" == things["edition"]:
            label.invoke()

    y = 80
    for (numb, server) in servers.items():
        add_server(numb, server, y)
        y += 50
def delete_server(file):
        delete = messagebox.askokcancel("Delete Server", "Are you sure you want to delete the server?", icon='warning')
        if delete:
            try:
                shutil.rmtree(MULTIMINE_PATH + file)
            except Exception as error:
                messagebox.showerror("Error",
                                     "An error occurred while deleting the file. Sorry for the problem.\nError: " + str(
                                         error), icon='error')
        versions()
def addworld(server, a):
    a.destroy()
    file = select_file(("zip files", "*.zip"))
    if file != "":
        try:
       shutil.unpack_archive(file, MULTIMINE_PATH+server+"worlds/")
        except Exception as error:
            messagebox.showerror("Error",
                                    "An error occurred while importing the file. Sorry for the problem.\nError: " + str(
                                        error), icon='error')
    worlds(server)
def viewminigames(a, b):
    webbrowser.open_new_tab("https://github.com/Bregalad2/MultiMine/wiki/Minigames")
def worlds(server):
    worldwindow = Toplevel(window)
    worldwindow.title(server + ' Worlds')
    worldwindow.geometry("450x350")
    window["background"] = Colors["Light"]["Cayan"]
    y = 50
    radiobuttons = []
    vworld = StringVar()
    vworld.set(1)
    worlds = {}
    for w in os.listdir(MULTIMINE_PATH + server + "/worlds"):
        worlds[w] = w

    def choose_world(info="info"):
        file = open(MULTIMINE_PATH + server + "/server.properties", "r", encoding="utf-8")
        lines = file.readlines()
        linenum = 0
        for line in lines:
            if "level-name=" in line:
                index = linenum
            linenum += 1
        if info != "info":
            lines[index] = "level-name=worlds/" + info + "\n"
            file.close()
            write = open(MULTIMINE_PATH + server + "/server.properties", "w", encoding="utf-8")
            write.write("".join(lines))
            write.close()
        try:
            return lines[index].split("/")[1].split("\n")[0]
        except IndexError:
            return lines[index].split("\n")[0]

    for (world, num) in worlds.items():
        worldselect = tkinter.ttk.Radiobutton(worldwindow, text=world.strip("/"), variable=vworld, value=num, )
        worldselect.pack(anchor=W)
        radiobuttons.append(worldselect)
        delete = tkinter.ttk.Button(worldwindow, text="Delete")
        y += 40
    tkinter.ttk.Button(worldwindow, text="Import…", command=lambda: addworld(server, a=worldwindow)).place(x=20,
                                                                                                                y=y)
    tkinter.ttk.Button(worldwindow, text="View Minigames",
            command=lambda: viewminigames(a=worldwindow, b=server)).place(x=120, y=y)
    y += 30
    tkinter.ttk.Button(worldwindow, text="Cancel", command=worldwindow.destroy).place(x=20, y=y)
    tkinter.ttk.Button(worldwindow, text="Save",
            command=lambda: (choose_world(info=vworld.get()), worldwindow.destroy())).place(x=120, y=y)

    for button in radiobuttons:
        if button["text"] == choose_world().split("\n")[0]:
            button.invoke()
def addserver():
    addwindow = Toplevel(window)
    addwindow.title('Add Server')
    addwindow.geometry("450x350")
    addwindow["background"] = Colors["Light"]["Cayan"]
    image = ""
    def select(): image += select_file(("All Png Files", "*.png"))
    global img
    img = ImageTk.PhotoImage(Image.open(MULTIMINE_PATH+"../Contents/Resources/Icon.png").resize((23,23), Image.ANTIALIAS))
    tkinter.ttk.Button(addwindow, image=img, command=select).place(y=20, x=50)
    tkinter.ttk.Label(addwindow, text="Name:").place(x=50, y=50)
    imput = tkinter.ttk.Entry(addwindow, font=('Minecraft'))
    imput.place(x=50, y=75)
    url = "https://launchermeta.mojang.com/mc/game/version_manifest.json"
    fetch_editions = urlopen(url).read().decode()
    editions_dict = json.loads(fetch_editions)
    editions = []
    for e in editions_dict["versions"]:
        if e["type"] == "release":
            editions.append(e["id"])
    tkinter.ttk.Label(addwindow, text="Edition:").place(x=50, y=100)
    ed = StringVar()
    ed.set(editions_dict["latest"]["release"])
    OptionMenu(addwindow, ed, *editions).place(x=50, y=125)
    tkinter.ttk.Button(addwindow, text="Add", command=lambda: endaddserver(a=addwindow, b={"edition": ed.get(), "name": imput.get(),"dict": editions_dict, "pic": image})).place(x=50, y=150)
def endaddserver(a, b):
    reset_window(w=a)
    os.mkdir(MULTIMINE_PATH + b["name"] + ".server")
    os.mkdir(MULTIMINE_PATH + b["name"] + ".server/worlds")
    for e in b["dict"]["versions"]:
        if e["id"] == b["edition"]:
            json_file = e["url"]
    js_string = urlopen(json_file).read().decode()
    js_dict = json.loads(js_string)
    jarfile = js_dict["downloads"]["server"]["url"]
    urlretrieve(jarfile, MULTIMINE_PATH + b["name"] + ".server/server.jar")
    if b["pic"]:
        change_icon(b["name"] + ".server", choose=b["pic"])
    else:
        change_icon(b["name"] + ".server", choose=MULTIMINE_PATH+"../Contents/Resources/Image.png")

def change_icon(server, choose=None):
    if not choose:
        file = select_file(("png files", "*.png"), ("JPEG files", "*.jpeg"), ("JPG files", "*.jpg"), ("WEBP files", "*.webp"))
    else:
        file = choose
    if file != "":
        os.remove(MULTIMINE_PATH+server+"/server-icon.png")
        image = Image.open(file)
        image.resize((64, 64)).save(MULTIMINE_PATH+server+"/server-icon.png", format="png")
