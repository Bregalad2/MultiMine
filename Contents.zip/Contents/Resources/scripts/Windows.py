from tkinter import *
import sys


MULTIMINE_PATH = sys.argv[1]
window = Tk()
setup = False

Colors = {"Blue": "#7159b5", 
        "Brown": "#6d4f37",
        "Lucy": "#b06b91",
        "Gold": "#c38627",
        "Cayan": "#af9cae",
        "Light": {
            "Blue": "#b5b4f9", 
            "Brown": "#a57b57",
            "Lucy": "#ffc1e5",
            "Gold": "#fdd31b",
            "Cayan": "#e4f0fc"
        },
        "Dark": {
            "Blue": "#383070", 
            "Brown": "#382a20",
            "Lucy": "#6c384e",
            "Gold": "#663f01",
            "Cayan": "#603950"
        }}

def onFrameConfigure(frame_small, windowp):
    frame_small.configure(scrollregion=(0, 0, 500, 1500))


frame_small = Canvas(window, background=Colors["Light"]["Cayan"], width=510, height=700, bd=0, highlightthickness=0, relief='ridge')
windowp = Frame(frame_small, background=Colors["Light"]["Cayan"], width=510, height=1200, borderwidth=0)
vsb = Scrollbar(window, orient="vertical", command=frame_small.yview)
frame_small.configure(yscrollcommand=vsb.set)
vsb.pack(side="right", fill="y")
frame_small.place(x=170, y=0)
frame_small.create_window((4, 4), window=windowp, anchor="nw")

windowp.bind("<Configure>", lambda event, frame_small=frame_small: onFrameConfigure(frame_small, windowp))

Commands = {
    ""
}
